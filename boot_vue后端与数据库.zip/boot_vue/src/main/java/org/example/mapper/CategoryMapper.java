package org.example.mapper;

import org.apache.ibatis.annotations.*;
import org.example.pojo.Category;

import java.util.List;

@Mapper
public interface CategoryMapper {
    //插入数据
    @Insert("insert into category(category_name, category_alias, create_user, create_time, update_time) " +
            "values (#{categoryName},#{categoryAlias},#{createUser},#{createTime},#{updateTime})")
    void add(Category category);
    //查询该用户的所有分类
    @Select("select * from category where create_user = #{userId}")
    List<Category> list(Integer userId);
    @Select("select * from category where id = #{id}")
    Category findById(Integer id);
    //更新分类
    @Update("update category set category_name=#{categoryName},category_alias=#{categoryAlias},"+
            "update_time=#{updateTime} where id=#{id}")
    void update(Category category);
    @Delete("delete from category where id = #{id}")
    void deleteById(Integer id);
}
